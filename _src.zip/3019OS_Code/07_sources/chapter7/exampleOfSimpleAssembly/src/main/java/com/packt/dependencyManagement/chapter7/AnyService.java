package com.packt.dependencyManagement.chapter7;

public interface AnyService {
    void anyMethod();
}
