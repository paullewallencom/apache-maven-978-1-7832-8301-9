package com.packt.dependencyManagement.chapter7;

public interface AnyDao {
    String getAnyString();
}