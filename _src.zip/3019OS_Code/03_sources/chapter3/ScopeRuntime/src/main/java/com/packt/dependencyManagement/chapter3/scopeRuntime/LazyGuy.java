package com.packt.dependencyManagement.chapter3.scopeRuntime;

public class LazyGuy {
    public static void main(String[] args) {
        System.out.println("I am lazy");
    }
}
