package com.packt.dependencyManagement.chapter3;

import org.easymock.classextension.EasyMock;
import org.junit.Test;

public class ScopeTestClass {

    @Test
    public void scopeTestMethod() {
        final EasyMock easyMock = null;
    }
}
