package com.packt.maven.dependencyManagement.tools4IDEs;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "dossierClientBean")
public class DossierClientBean {

    public DossierClientBean() {
        super();
    }

}
