package com.packt.maven.dependency.projectFromAnt;

import org.junit.Test;

/**
 * Created with IntelliJ IDEA "Leda" 12 CE.
 * User: Jonathan LALOU
 */
public class AnyClassUnitTest {
    @Test
    public void testAnyClass() {
        // test OK, nothing to do
    }
}
